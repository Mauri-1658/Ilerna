<?php
// Parámetros de conexión a la base de datos
$db_host = 'localhost';
$db_name = 'empresa';
$db_user = 'root';
$db_pass = '';

// DSN para PDO (codificación utf8mb4)
$dsn = "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4";
?>