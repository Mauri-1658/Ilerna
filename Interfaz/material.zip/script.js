function validar() {
    alert("Formulario enviado");
}